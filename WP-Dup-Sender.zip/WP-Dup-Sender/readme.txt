
		- Created by </Mr.PuNk> , 
		- WebSite : https://mohamadjavadkarimi.ir/
		- Plugin Version : v1.3.1

	- Changelog:
		- Use uploads/BackupSite as fixed destination
		- Prevent duplicate sends
		- Manual send button in dashboard
		- Automatically send webhook receipts for           Telegram bots to your hosting address
		- added site_url setting and use it to              form download links in messages.
